import nice.palettes.*;

ColorPalette palette;

int margin = 0;

void setup() {
  size(400,400);
  pixelDensity(2);
  smooth();
  
  palette = new ColorPalette(this);
  palette.refresh();
  //println(palette.getPaletteRandom());
  //println(palette.getPalette(10));
  
  color[] colors = palette.getPalette(300);
  
  //printArray(colors);
  
  for(int x = 0; x < 100; x++) {
    for(int y = 0; y < 100; y++) {
      int z = int(random(0, colors.length));
      fill(colors[z]);
      ellipse(margin + x * 10,  margin + y * 10, 10, 10);
    }
  }
  //printArray(colors);
  noLoop();
}

void draw() {
}
